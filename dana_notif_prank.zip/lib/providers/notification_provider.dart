import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:vibration/vibration.dart';
import 'package:intl/intl.dart';
import 'package:permission_handler/permission_handler.dart';

class NotificationProvider extends ChangeNotifier {
  final FlutterLocalNotificationsPlugin _flutterLocalNotificationsPlugin =
      FlutterLocalNotificationsPlugin();
  final AudioPlayer _audioPlayer = AudioPlayer();
  bool _isPlaying = false;
  bool _isInitialized = false;

  NotificationProvider() {
    _initializeNotifications();
  }

  Future<void> requestPermissions() async {
    if (await Permission.notification.isDenied) {
      await Permission.notification.request();
    }
    if (await Permission.vibrate.isDenied) {
      await Permission.vibrate.request();
    }
  }

  Future<void> _initializeNotifications() async {
    if (_isInitialized) return;
    const AndroidInitializationSettings initializationSettingsAndroid =
        AndroidInitializationSettings('@mipmap/ic_launcher');
    const DarwinInitializationSettings initializationSettingsIOS =
        DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );
    const InitializationSettings initializationSettings =
        InitializationSettings(
      android: initializationSettingsAndroid,
      iOS: initializationSettingsIOS,
    );
    await _flutterLocalNotificationsPlugin.initialize(
      initializationSettings,
      onDidReceiveNotificationResponse: (details) {
        debugPrint('Notification tapped: ${details.payload}');
      },
    );

    const AndroidNotificationChannel channel = AndroidNotificationChannel(
      'dana_channel',
      'DANA Notifications',
      description: 'Notifikasi dari DANA Notif Prank',
      importance: Importance.max,
      playSound: true,
      enableVibration: true,
      vibrationPattern: [0, 500, 200, 500],
    );
    await _flutterLocalNotificationsPlugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);
    _isInitialized = true;
  }

  Future<bool> sendPrankNotification({
    required int amount,
    required int duration,
  }) async {
    try {
      if (!_isInitialized) {
        await _initializeNotifications();
      }
      await _showNotification(amount);
      await _playNotificationSound();
      await Future.delayed(Duration(seconds: duration));
      await _showConfirmationNotification(amount);
      return true;
    } catch (e) {
      debugPrint('Error sending notification: $e');
      return false;
    }
  }

  Future<void> _showNotification(int amount) async {
    final formattedAmount = NumberFormat.currency(
      locale: 'id_ID',
      symbol: 'Rp ',
      decimalDigits: 0,
    ).format(amount);

    const AndroidNotificationDetails androidPlatformChannelSpecifics =
        AndroidNotificationDetails(
      'dana_channel',
      'DANA Notifications',
      channelDescription: 'Notifikasi dari DANA',
      importance: Importance.max,
      priority: Priority.high,
      ticker: 'ticker',
      sound: RawResourceAndroidNotificationSound('dana_notification'),
      enableVibration: true,
      vibrationPattern: [0, 500, 200, 500],
      styleInformation: BigTextStyleInformation(''),
      autoCancel: true,
      color: Color(0xFF1A73E8),
      colorized: true,
      icon: '@mipmap/ic_launcher',
      visibility: NotificationVisibility.public,
      category: AndroidNotificationCategory.reminder,
      channelShowBadge: true,
      timeoutAfter: 5000,
    );
    const DarwinNotificationDetails iOSPlatformChannelSpecifics =
        DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
      sound: 'dana_notification.caf',
      interruptionLevel: InterruptionLevel.timeSensitive,
    );
    const NotificationDetails platformChannelSpecifics = NotificationDetails(
      android: androidPlatformChannelSpecifics,
      iOS: iOSPlatformChannelSpecifics,
    );
    await _flutterLocalNotificationsPlugin.show(
      0,
      '  DANA',
      'Anda menerima $formattedAmount masuk ke DANA',
      platformChannelSpecifics,
      payload: 'dana_notification',
    );
  }

  Future<void> _showConfirmationNotification(int amount) async {
    final formattedAmount = NumberFormat.currency(
      locale: 'id_ID',
      symbol: 'Rp ',
      decimalDigits: 0,
    ).format(amount);

    const AndroidNotificationDetails androidPlatformChannelSpecifics =
        AndroidNotificationDetails(
      'dana_channel',
      'DANA Notifications',
      channelDescription: 'Notifikasi dari DANA',
      importance: Importance.max,
      priority: Priority.high,
      ticker: 'ticker',
      sound: RawResourceAndroidNotificationSound('dana_notification'),
      enableVibration: true,
      vibrationPattern: [0, 300, 100, 300],
      styleInformation: BigTextStyleInformation(''),
      autoCancel: true,
      color: Color(0xFF1A73E8),
      colorized: true,
      icon: '@mipmap/ic_launcher',
      visibility: NotificationVisibility.public,
      category: AndroidNotificationCategory.reminder,
      channelShowBadge: true,
    );
    const DarwinNotificationDetails iOSPlatformChannelSpecifics =
        DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
      sound: 'dana_notification.caf',
      interruptionLevel: InterruptionLevel.timeSensitive,
    );
    const NotificationDetails platformChannelSpecifics = NotificationDetails(
      android: androidPlatformChannelSpecifics,
      iOS: iOSPlatformChannelSpecifics,
    );
    await _flutterLocalNotificationsPlugin.show(
      1,
      '  Transaksi Berhasil',
      'Saldo DANA Anda bertambah $formattedAmount',
      platformChannelSpecifics,
      payload: 'dana_confirmation',
    );
  }

  Future<void> _playNotificationSound() async {
    try {
      if (await Vibration.hasVibrator() ?? false) {
        Vibration.vibrate(pattern: [0, 500, 200, 500]);
      }
      _isPlaying = true;
      await _audioPlayer.setVolume(1.0);
      await _audioPlayer.play(
        AssetSource('sounds/dana_notification.mp3'),
      );
      _isPlaying = false;
    } catch (e) {
      debugPrint('Error playing sound: $e');
      _isPlaying = false;
    }
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    super.dispose();
  }
}
