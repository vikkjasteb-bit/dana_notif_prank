import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import 'package:dana_notif_prank/providers/notification_provider.dart';
import 'package:dana_notif_prank/widgets/custom_text_field.dart';
import 'package:dana_notif_prank/widgets/action_button.dart';
import 'package:dana_notif_prank/widgets/dana_card.dart';
import 'package:dana_notif_prank/screens/notification_preview.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _formKey = GlobalKey<FormState>();
  final _amountController = TextEditingController();
  final _durationController = TextEditingController();
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _requestPermissions();
  }

  Future<void> _requestPermissions() async {
    final provider = context.read<NotificationProvider>();
    await provider.requestPermissions();
  }

  @override
  void dispose() {
    _amountController.dispose();
    _durationController.dispose();
    super.dispose();
  }

  Future<void> _sendPrankNotification() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isLoading = true);
    final provider = context.read<NotificationProvider>();
    final amount = int.parse(_amountController.text.replaceAll('.', ''));
    final duration = int.parse(_durationController.text);

    if (mounted) {
      final result = await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => NotificationPreview(
            amount: amount,
            duration: duration,
          ),
        ),
      );
      if (result == true) {
        final success = await provider.sendPrankNotification(
          amount: amount,
          duration: duration,
        );
        setState(() => _isLoading = false);
        if (success && mounted) {
          _showSnackBar('Notifikasi berhasil dikirim!', Colors.green);
        } else if (mounted) {
          _showSnackBar('Gagal mengirim notifikasi', Colors.red);
        }
      } else {
        setState(() => _isLoading = false);
      }
    }
  }

  void _showSnackBar(String message, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: color,
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  String _formatCurrency(String value) {
    if (value.isEmpty) return '';
    final number = int.tryParse(value.replaceAll('.', ''));
    if (number == null) return value;
    return NumberFormat.currency(
      locale: 'id_ID',
      symbol: '',
      decimalDigits: 0,
    ).format(number);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Image.asset(
              'assets/images/dana_logo.png',
              height: 30,
              errorBuilder: (_, __, ___) => const Icon(
                Icons.account_balance_wallet,
                color: Colors.white,
                size: 28,
              ),
            ),
            const SizedBox(width: 10),
            const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'DANA Notif Prank',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                  ),
                ),
                Text(
                  'By @vikk_official1',
                  style: TextStyle(
                    fontSize: 9,
                    color: Colors.white70,
                  ),
                ),
              ],
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.info_outline),
            onPressed: _showInfoDialog,
          ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              const Color(0xFF1A73E8).withOpacity(0.1),
              Colors.white,
              Colors.white,
            ],
            stops: const [0.0, 0.3, 1.0],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 10),
                  _buildHeaderCard(),
                  const SizedBox(height: 20),
                  _buildInputSection(),
                  const SizedBox(height: 20),
                  _buildPreviewCard(),
                  const SizedBox(height: 25),
                  ActionButton(
                    onPressed: _isLoading ? null : _sendPrankNotification,
                    isLoading: _isLoading,
                    label: 'KIRIM PRANK',
                  ),
                  const SizedBox(height: 15),
                  Center(
                    child: Text(
                      'Gunakan untuk hiburan saja',
                      style: TextStyle(
                        color: Colors.grey[600],
                        fontSize: 11,
                        fontStyle: FontStyle.italic,
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  Center(
                    child: Text(
                      'Developer @vikk_official1',
                      style: TextStyle(
                        color: Colors.grey[400],
                        fontSize: 10,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeaderCard() {
    return const DanaCard(
      child: Row(
        children: [
          Icon(Icons.notifications_active, color: Color(0xFF1A73E8), size: 30),
          SizedBox(width: 15),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Prank Notification',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  'Kirim notifikasi palsu seperti asli',
                  style: TextStyle(
                    color: Colors.grey,
                    fontSize: 13,
                  ),
                ),
              ],
            ),
          ),
          Chip(
            label: Text('PRANK', style: TextStyle(fontSize: 11)),
            backgroundColor: Colors.orange,
            labelStyle: TextStyle(color: Colors.white),
            padding: EdgeInsets.symmetric(horizontal: 8),
          ),
        ],
      ),
    );
  }

  Widget _buildInputSection() {
    return DanaCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Isi Detail Prank',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 5),
          Text(
            'Masukkan data sesuai keinginan',
            style: TextStyle(
              color: Colors.grey[600],
              fontSize: 13,
            ),
          ),
          const SizedBox(height: 20),
          CustomTextField(
            controller: _amountController,
            label: 'Jumlah Uang',
            hint: 'Contoh: 100000',
            prefixText: 'Rp ',
            keyboardType: TextInputType.number,
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Masukkan jumlah uang';
              }
              final number = int.tryParse(value.replaceAll('.', ''));
              if (number == null || number <= 0) {
                return 'Masukkan angka yang valid';
              }
              if (number > 1000000000) {
                return 'Maksimal Rp 1.000.000.000';
              }
              return null;
            },
            onChanged: (value) {
              final formatted = _formatCurrency(value);
              if (formatted != value && formatted.isNotEmpty) {
                _amountController.value = TextEditingValue(
                  text: formatted,
                  selection: TextSelection.collapsed(offset: formatted.length),
                );
              }
            },
          ),
          const SizedBox(height: 16),
          CustomTextField(
            controller: _durationController,
            label: 'Durasi (detik)',
            hint: 'Contoh: 3',
            keyboardType: TextInputType.number,
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Masukkan durasi';
              }
              final number = int.tryParse(value);
              if (number == null || number <= 0) {
                return 'Masukkan angka positif';
              }
              if (number > 60) {
                return 'Maksimal 60 detik';
              }
              return null;
            },
          ),
        ],
      ),
    );
  }

  Widget _buildPreviewCard() {
    final amount = _amountController.text.isEmpty
        ? 'Rp 0'
        : 'Rp ${_amountController.text}';
    final duration = _durationController.text.isEmpty
        ? '0 detik'
        : '${_durationController.text} detik';
    return DanaCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Preview Notifikasi',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 15),
          Container(
            padding: const EdgeInsets.all(15),
            decoration: BoxDecoration(
              color: Colors.grey[50],
              borderRadius: BorderRadius.circular(15),
              border: Border.all(color: Colors.grey[200]!),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.blue[100],
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(
                    Icons.account_balance_wallet,
                    color: Color(0xFF1A73E8),
                    size: 28,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'DANA',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                          color: Colors.black87,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        '$amount masuk ke DANA',
                        style: const TextStyle(
                          fontSize: 14,
                          color: Colors.black87,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Row(
                        children: [
                          Icon(Icons.timer, size: 14, color: Colors.grey[600]),
                          const SizedBox(width: 4),
                          Text(
                            'Dalam $duration',
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.grey[600],
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _showInfoDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Tentang Aplikasi'),
        content: const Text('DANA Notif Prank adalah aplikasi hiburan untuk membuat prank notifikasi.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Tutup'),
          ),
        ],
      ),
    );
  }
}
