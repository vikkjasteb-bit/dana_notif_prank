import 'package:intl/intl.dart';

class Helpers {
  static String formatRupiah(int amount) {
    return NumberFormat.currency(
      locale: 'id_ID',
      symbol: 'Rp ',
      decimalDigits: 0,
    ).format(amount);
  }

  static bool isValidAmount(String value) {
    final number = int.tryParse(value.replaceAll('.', ''));
    if (number == null) return false;
    return number > 0 && number <= 1000000000;
  }
}
