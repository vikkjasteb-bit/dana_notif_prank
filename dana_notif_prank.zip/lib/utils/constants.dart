class AppConstants {
  static const String appName = 'DANA Notif Prank';
  static const String developer = '@vikk_official1';
  static const String version = '1.0.0';
  
  static const Color primaryColor = Color(0xFF1A73E8);
  static const Color secondaryColor = Color(0xFF0D47A1);
  static const Color accentColor = Color(0xFFFF6B00);
  
  static const double defaultPadding = 20.0;
  static const double borderRadius = 20.0;
}

class NotificationConstants {
  static const String channelId = 'dana_channel';
  static const String channelName = 'DANA Notifications';
  static const String channelDescription = 'Notifikasi dari DANA Notif Prank';
  static const String soundFileName = 'dana_notification.mp3';
}