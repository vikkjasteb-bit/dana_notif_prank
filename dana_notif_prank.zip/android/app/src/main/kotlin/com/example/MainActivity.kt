package com.example.dana_notif_prank

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
