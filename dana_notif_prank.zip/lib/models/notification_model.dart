class NotificationModel {
  final int id;
  final String title;
  final String body;
  final int amount;
  final int duration;
  final DateTime timestamp;

  NotificationModel({
    required this.id,
    required this.title,
    required this.body,
    required this.amount,
    required this.duration,
    required this.timestamp,
  });

  factory NotificationModel.fromMap(Map<String, dynamic> map) {
    return NotificationModel(
      id: map['id'] ?? 0,
      title: map['title'] ?? '',
      body: map['body'] ?? '',
      amount: map['amount'] ?? 0,
      duration: map['duration'] ?? 0,
      timestamp: DateTime.parse(map['timestamp'] ?? DateTime.now().toIso8601String()),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'body': body,
      'amount': amount,
      'duration': duration,
      'timestamp': timestamp.toIso8601String(),
    };
  }
}
