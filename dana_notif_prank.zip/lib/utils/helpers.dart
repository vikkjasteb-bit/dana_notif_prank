import 'package:intl/intl.dart';

class Helpers {
  static String formatRupiah(int amount) {
    return NumberFormat.currency(
      locale: 'id_ID',
      symbol: 'Rp ',
      decimalDigits: 0,
    ).format(amount);
  }

  static String formatDate(DateTime date) {
    return DateFormat('dd MMM yyyy, HH:mm').format(date);
  }

  static bool isValidAmount(String value) {
    final number = int.tryParse(value.replaceAll('.', ''));
    if (number == null) return false;
    return number > 0 && number <= 1000000000;
  }

  static bool isValidDuration(String value) {
    final number = int.tryParse(value);
    if (number == null) return false;
    return number > 0 && number <= 60;
  }
}