import 'package:flutter/material.dart';

class AppConstants {
  static const String appName = 'DANA Notif Prank';
  static const String developer = '@vikk_official1';
  static const String version = '1.0.0';
  static const Color primaryColor = Color(0xFF1A73E8);
}

class NotificationConstants {
  static const String channelId = 'dana_channel';
  static const String channelName = 'DANA Notifications';
}
